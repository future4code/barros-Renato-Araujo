export abstract class Pessoa{
   protected id:string;
   protected nome:string;
   protected email:string;
   protected dataNascimento:Date;
   protected turma:string;

   protected static altura=`muito alto!`
    constructor(id:string, nome:string, email:string , dataNascimento:Date, turma:string){
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.dataNascimento = dataNascimento;
        this.turma = turma;
    }

    public static mensagem(){
        console.log(`òola mundo` );
        
    }
    public static saudacao(nome:string){
        console.log(`Olá ${nome} ! Prazer em te conhecer`);       
    }

    protected existencia(){
        return `Eu sou uma pessoa`;
    }
    public correr():void{
            console.log(`${this.nome} esta correndo!`);        
    }
}