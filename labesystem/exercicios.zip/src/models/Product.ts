export type Product_data = {
    name: string,
    price: number
}